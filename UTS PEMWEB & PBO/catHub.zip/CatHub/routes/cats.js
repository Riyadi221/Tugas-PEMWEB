const express = require("express");
const router = express.Router();
const catsController = require("../controllers/catsController");

// Routes for CRUD operations on cats
router.get("/", catsController.getAllCats);
router.get("/add", catsController.getAddCat);
router.post("/add", catsController.postAddCat);
router.get("/edit/:id", catsController.getEditCat);
router.post("/edit/:id", catsController.postEditCat);
router.get("/delete/:id", catsController.deleteCat);

module.exports = router;
