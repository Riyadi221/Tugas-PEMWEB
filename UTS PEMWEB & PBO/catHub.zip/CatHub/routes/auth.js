const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");

// Landing page route
router.get("/", (req, res) => {
  if (req.session.userId) {
    // If user is logged in, redirect to the dashboard
    res.redirect("/dashboard");
  } else {
    // Render landing page if not logged in
    res.render("landing");
  }
});

// Display login page
router.get("/login", authController.getLogin);

// Handle login form submission
router.post("/login", authController.postLogin);

// Display registration page
router.get("/register", authController.getRegister);

// Handle registration form submission
router.post("/register", authController.postRegister);

// Display forgot password page
router.get("/forgot-password", authController.getForgotPassword);

// Handle forgot password form submission
router.post("/forgot-password", authController.postForgotPassword);

// Display dashboard (home) page
router.get("/dashboard", authController.getDashboard);

// Display edit profile page
router.get("/edit-profile", authController.getEditProfile);

// Handle profile edit form submission
router.post("/edit-profile", authController.postEditProfile);

// Handle logout
router.get("/logout", authController.logout);

module.exports = router;
