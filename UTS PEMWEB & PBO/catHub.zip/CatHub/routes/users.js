const express = require("express");
const router = express.Router();
const usersController = require("../controllers/usersController");

// CRUD routes for users
router.get("/", usersController.getAllUsers); // List all users
router.get("/add", usersController.getAddUser); // Show form to add new user
router.post("/add", usersController.postAddUser); // Add new user
router.get("/edit/:id", usersController.getEditUser); // Show form to edit user
router.post("/edit/:id", usersController.postEditUser); // Update user details
router.get("/delete/:id", usersController.deleteUser); // Delete user

// Existing CRUD routes for users...
router.get("/forgot-password", usersController.getForgotPassword); // Show forgot password form
router.post("/forgot-password", usersController.postForgotPassword); // Handle forgot password form
router.get("/reset-password/:token", usersController.getResetPassword); // Show reset password form with token
router.post("/reset-password/:token", usersController.postResetPassword); // Handle reset password form

module.exports = router;

module.exports = router;
