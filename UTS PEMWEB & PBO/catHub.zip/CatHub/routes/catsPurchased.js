const express = require("express");
const router = express.Router();
const catsPurchasedController = require("../controllers/catsPurchasedController");

// CRUD routes for purchased cats
router.get("/", catsPurchasedController.getAllPurchasedCats); // List all purchased cats
router.get("/add", catsPurchasedController.getAddPurchasedCat); // Show form to add purchased cat
router.post("/add", catsPurchasedController.postAddPurchasedCat); // Add purchased cat
router.get("/edit/:id", catsPurchasedController.getEditPurchasedCat); // Show form to edit purchased cat
router.post("/edit/:id", catsPurchasedController.postEditPurchasedCat); // Update purchased cat
router.get("/delete/:id", catsPurchasedController.deletePurchasedCat); // Delete purchased cat

module.exports = router;
