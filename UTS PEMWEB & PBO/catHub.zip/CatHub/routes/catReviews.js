const express = require("express");
const router = express.Router();
const catReviewsController = require("../controllers/catReviewsController");

// CRUD routes for cat reviews
router.get("/", catReviewsController.getAllReviews); // List all reviews
router.get("/add", catReviewsController.getAddReview); // Show form to add review
router.post("/add", catReviewsController.postAddReview); // Add new review
router.get("/edit/:id", catReviewsController.getEditReview); // Show form to edit review
router.post("/edit/:id", catReviewsController.postEditReview); // Update review details
router.get("/delete/:id", catReviewsController.deleteReview); // Delete review

module.exports = router;
