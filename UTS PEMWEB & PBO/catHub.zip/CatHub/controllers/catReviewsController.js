const db = require("../config/db");

// Display all reviews
exports.getAllReviews = (req, res) => {
  db.query("SELECT * FROM cat_reviews", (err, results) => {
    if (err) throw err;
    res.render("reviews-list", { reviews: results });
  });
};

// Display form to add a review
exports.getAddReview = (req, res) => {
  res.render("add-review");
};

// Add a new review
exports.postAddReview = (req, res) => {
  const { cat_id, user_id, review_text, rating } = req.body;

  db.query(
    "INSERT INTO cat_reviews (cat_id, user_id, review_text, rating) VALUES (?, ?, ?, ?)",
    [cat_id, user_id, review_text, rating],
    (err) => {
      if (err) throw err;
      res.redirect("/cat-reviews");
    }
  );
};

// Display form to edit a review
exports.getEditReview = (req, res) => {
  const reviewId = req.params.id;
  db.query(
    "SELECT * FROM cat_reviews WHERE id = ?",
    [reviewId],
    (err, results) => {
      if (err) throw err;
      if (results.length === 0) return res.send("Review not found");
      res.render("edit-review", { review: results[0] });
    }
  );
};

// Update review details
exports.postEditReview = (req, res) => {
  const reviewId = req.params.id;
  const { review_text, rating } = req.body;

  db.query(
    "UPDATE cat_reviews SET review_text = ?, rating = ? WHERE id = ?",
    [review_text, rating, reviewId],
    (err) => {
      if (err) throw err;
      res.redirect("/cat-reviews");
    }
  );
};

// Delete a review
exports.deleteReview = (req, res) => {
  const reviewId = req.params.id;
  db.query("DELETE FROM cat_reviews WHERE id = ?", [reviewId], (err) => {
    if (err) throw err;
    res.redirect("/cat-reviews");
  });
};
