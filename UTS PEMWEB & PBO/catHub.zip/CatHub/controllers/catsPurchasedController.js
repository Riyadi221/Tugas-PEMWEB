const db = require("../config/db");

// Display all purchased cats
exports.getAllPurchasedCats = (req, res) => {
  db.query("SELECT * FROM cats_purchased", (err, results) => {
    if (err) throw err;
    res.render("cats-purchased-list", { purchasedCats: results });
  });
};

// Display form to add a purchased cat
exports.getAddPurchasedCat = (req, res) => {
  res.render("add-purchased-cat");
};

// Add a new purchased cat
exports.postAddPurchasedCat = (req, res) => {
  const { cat_id, user_id, purchase_date, status } = req.body;

  db.query(
    "INSERT INTO cats_purchased (cat_id, user_id, purchase_date, status) VALUES (?, ?, ?, ?)",
    [cat_id, user_id, purchase_date, status],
    (err) => {
      if (err) throw err;
      res.redirect("/cats-purchased");
    }
  );
};

// Display form to edit a purchased cat
exports.getEditPurchasedCat = (req, res) => {
  const purchasedCatId = req.params.id;
  db.query(
    "SELECT * FROM cats_purchased WHERE id = ?",
    [purchasedCatId],
    (err, results) => {
      if (err) throw err;
      if (results.length === 0) return res.send("Purchased cat not found");
      res.render("edit-purchased-cat", { purchasedCat: results[0] });
    }
  );
};

// Update purchased cat details
exports.postEditPurchasedCat = (req, res) => {
  const purchasedCatId = req.params.id;
  const { purchase_date, status } = req.body;

  db.query(
    "UPDATE cats_purchased SET purchase_date = ?, status = ? WHERE id = ?",
    [purchase_date, status, purchasedCatId],
    (err) => {
      if (err) throw err;
      res.redirect("/cats-purchased");
    }
  );
};

// Delete a purchased cat record
exports.deletePurchasedCat = (req, res) => {
  const purchasedCatId = req.params.id;
  db.query(
    "DELETE FROM cats_purchased WHERE id = ?",
    [purchasedCatId],
    (err) => {
      if (err) throw err;
      res.redirect("/cats-purchased");
    }
  );
};
