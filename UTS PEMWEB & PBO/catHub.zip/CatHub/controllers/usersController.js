const db = require("../config/db");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");

// Display all users
exports.getAllUsers = (req, res) => {
  db.query("SELECT id, name, email, created_at FROM users", (err, results) => {
    if (err) throw err;
    res.render("users-list", { users: results });
  });
};

// Display form to add a new user
exports.getAddUser = (req, res) => {
  res.render("add-user");
};

// Add a new user
exports.postAddUser = async (req, res) => {
  const { name, email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  db.query(
    "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
    [name, email, hashedPassword],
    (err) => {
      if (err) throw err;
      res.redirect("/users");
    }
  );
};

// Display form to edit a user
exports.getEditUser = (req, res) => {
  const userId = req.params.id;
  db.query(
    "SELECT id, name, email FROM users WHERE id = ?",
    [userId],
    (err, results) => {
      if (err) throw err;
      if (results.length === 0) return res.send("User not found");
      res.render("edit-user", { user: results[0] });
    }
  );
};

// Update user details
exports.postEditUser = async (req, res) => {
  const userId = req.params.id;
  const { name, email, password } = req.body;

  // Update password only if a new one is provided
  const hashedPassword = password ? await bcrypt.hash(password, 10) : null;
  const query = hashedPassword
    ? "UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?"
    : "UPDATE users SET name = ?, email = ? WHERE id = ?";
  const values = hashedPassword
    ? [name, email, hashedPassword, userId]
    : [name, email, userId];

  db.query(query, values, (err) => {
    if (err) throw err;
    res.redirect("/users");
  });
};

// Delete a user
exports.deleteUser = (req, res) => {
  const userId = req.params.id;
  db.query("DELETE FROM users WHERE id = ?", [userId], (err) => {
    if (err) throw err;
    res.redirect("/users");
  });
};

const nodemailer = require("nodemailer"); // For email functionality

// Show forgot password form
exports.getForgotPassword = (req, res) => {
  res.render("forgot-password");
};

// Handle forgot password form submission
exports.postForgotPassword = (req, res) => {
  const { email } = req.body;
  const resetToken = crypto.randomBytes(32).toString("hex");
  const resetTokenExpires = new Date(Date.now() + 3600000); // 1-hour expiration

  db.query(
    "UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE email = ?",
    [resetToken, resetTokenExpires, email],
    (err, result) => {
      if (err) throw err;

      // If user with this email exists
      if (result.affectedRows > 0) {
        // Send reset email
        const resetUrl = `http://localhost:3000/users/reset-password/${resetToken}`;
        const transporter = nodemailer.createTransport({
          service: "Gmail", // Example provider, configure as needed
          auth: {
            user: "your-email@gmail.com", // Replace with your email
            pass: "your-password", // Replace with your email password
          },
        });

        const mailOptions = {
          to: email,
          subject: "Password Reset",
          text: `You requested a password reset. Click here to reset: ${resetUrl}`,
        };

        transporter.sendMail(mailOptions, (error) => {
          if (error) {
            console.log("Error sending email:", error);
            return res.send("Error sending email. Please try again.");
          }
          res.send("Password reset email sent. Please check your inbox.");
        });
      } else {
        res.send("No account found with that email.");
      }
    }
  );
};

// Show reset password form with token
exports.getResetPassword = (req, res) => {
  const { token } = req.params;

  db.query(
    "SELECT * FROM users WHERE reset_token = ? AND reset_token_expires > NOW()",
    [token],
    (err, results) => {
      if (err) throw err;
      if (results.length === 0) {
        return res.send("Invalid or expired token.");
      }
      res.render("reset-password", { token });
    }
  );
};

// Handle reset password form submission
exports.postResetPassword = async (req, res) => {
  const { token } = req.params;
  const { password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  db.query(
    "UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE reset_token = ?",
    [hashedPassword, token],
    (err, result) => {
      if (err) throw err;
      if (result.affectedRows === 0) {
        return res.send("Invalid or expired token.");
      }
      res.send("Password has been reset successfully.");
    }
  );
};
