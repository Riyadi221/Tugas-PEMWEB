const db = require("../config/db");

// Display all cats
exports.getAllCats = (req, res) => {
  db.query("SELECT * FROM cats_for_sale", (err, results) => {
    if (err) throw err;
    res.render("cats-list", { cats: results });
  });
};

// Display form to add a new cat
exports.getAddCat = (req, res) => {
  res.render("add-cat");
};

// Add a new cat
exports.postAddCat = (req, res) => {
  const { name, breed, price } = req.body;

  if (!name || !breed || !price) {
    return res.status(400).send("All fields are required.");
  }

  db.query(
    "INSERT INTO cats_for_sale (name, breed, price) VALUES (?, ?, ?)",
    [name, breed, price],
    (err) => {
      if (err) throw err;
      res.redirect("/cats");
    }
  );
};

// Display form to edit a cat's details
exports.getEditCat = (req, res) => {
  const catId = req.params.id;
  db.query(
    "SELECT * FROM cats_for_sale WHERE id = ?",
    [catId],
    (err, results) => {
      if (err) throw err;
      if (results.length === 0) return res.status(404).send("Cat not found.");
      res.render("edit-cat", { cat: results[0] });
    }
  );
};

// Update a cat's details
exports.postEditCat = (req, res) => {
  const catId = req.params.id;
  const { name, breed, price } = req.body;

  if (!name || !breed || !price) {
    return res.status(400).send("All fields are required.");
  }

  db.query(
    "UPDATE cats_for_sale SET name = ?, breed = ?, price = ? WHERE id = ?",
    [name, breed, price, catId],
    (err) => {
      if (err) throw err;
      res.redirect("/cats");
    }
  );
};

// Delete a cat
exports.deleteCat = (req, res) => {
  const catId = req.params.id;
  db.query("DELETE FROM cats_for_sale WHERE id = ?", [catId], (err) => {
    if (err) throw err;
    res.redirect("/cats");
  });
};
