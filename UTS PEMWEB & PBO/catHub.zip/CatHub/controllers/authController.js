const bcrypt = require("bcryptjs");
const db = require("../config/db");
const nodemailer = require("nodemailer");
const crypto = require("crypto");

// Display login page
exports.getLogin = (req, res) => {
  res.render("login");
};

// Handle login form submission
exports.postLogin = (req, res) => {
  const { email, password } = req.body;

  db.query(
    "SELECT * FROM users WHERE email = ?",
    [email],
    async (err, results) => {
      if (err) throw err;

      if (results.length === 0) {
        return res.status(400).render("login", { error: "User not found" });
      }

      const user = results[0];
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(400).render("login", { error: "Incorrect password" });
      }

      req.session.userId = user.id;
      req.session.userName = user.name;

      // Redirect to dashboard after login
      res.redirect("/dashboard");
    }
  );
};

// Display registration page
exports.getRegister = (req, res) => {
  res.render("register");
};

// Handle registration form submission
exports.postRegister = async (req, res) => {
  const { name, email, password } = req.body;

  try {
    const [user] = await db
      .promise()
      .query("SELECT * FROM users WHERE email = ?", [email]);
    if (user.length > 0) {
      return res.render("register", { error: "Email already in use" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    await db
      .promise()
      .query("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", [
        name,
        email,
        hashedPassword,
      ]);

    res.redirect("/login");
  } catch (err) {
    console.error(err);
    res.status(500).send("An error occurred during registration");
  }
};

// Display forgot password page
exports.getForgotPassword = (req, res) => {
  res.render("forgot-password");
};

// Handle forgot password form submission
exports.postForgotPassword = async (req, res) => {
  const { email } = req.body;
  const resetToken = crypto.randomBytes(32).toString("hex");
  const resetTokenExpires = Date.now() + 3600000; // 1 hour

  try {
    const [user] = await db
      .promise()
      .query("SELECT * FROM users WHERE email = ?", [email]);
    if (user.length === 0) {
      return res.render("forgot-password", { error: "Email not found" });
    }

    await db
      .promise()
      .query(
        "UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE email = ?",
        [resetToken, resetTokenExpires, email]
      );

    const transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: process.env.EMAIL_PORT,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const resetURL = `http://localhost:3000/reset-password/${resetToken}`;
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: "Password Reset",
      text: `Reset your password by clicking this link: ${resetURL}`,
    });

    res.render("forgot-password", {
      message: "Check your email for password reset instructions",
    });
  } catch (err) {
    console.error(err);
    res.status(500).send("An error occurred");
  }
};

// Display dashboard page
exports.getDashboard = (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login"); // Redirect to login if not authenticated
  }
  res.render("dashboard", { userName: req.session.userName });
};

// Display edit profile page
exports.getEditProfile = (req, res) => {
  // Check if the user is logged in
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  // Retrieve user data from the database to prefill the form
  db.query(
    "SELECT * FROM users WHERE id = ?",
    [req.session.userId],
    (err, results) => {
      if (err) throw err;
      const user = results[0];
      res.render("edit-profile", { user });
    }
  );
};

// Handle profile edit form submission
exports.postEditProfile = async (req, res) => {
  const { name, email, password } = req.body;
  const userId = req.session.userId;

  try {
    // If password is provided, hash it
    let hashedPassword = null;
    if (password) {
      hashedPassword = await bcrypt.hash(password, 10);
    }

    // Update the user's profile in the database
    const updateQuery = hashedPassword
      ? "UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?"
      : "UPDATE users SET name = ?, email = ? WHERE id = ?";

    const values = hashedPassword
      ? [name, email, hashedPassword, userId]
      : [name, email, userId];
    db.query(updateQuery, values, (err) => {
      if (err) throw err;
      res.redirect("/dashboard");
    });
  } catch (err) {
    console.error(err);
    res.status(500).send("An error occurred while updating profile");
  }
};

// Handle logout and destroy session
exports.logout = (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error(err);
      return res.status(500).send("An error occurred while logging out");
    }
    res.redirect("/"); // Redirect to landing page after logout
  });
};
