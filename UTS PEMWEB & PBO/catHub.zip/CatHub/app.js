require("dotenv").config();
const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const path = require("path");
const app = express();
const multer = require("multer");
const upload = multer({ dest: "public/uploads/" });
const fileUpload = require("express-fileupload");

const catsPurchasedRoutes = require("./routes/catsPurchased");
const usersRoutes = require("./routes/users");
const catReviewsRoutes = require("./routes/catReviews");

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(fileUpload()); // Enable file upload middleware

app.use(express.static(path.join(__dirname, "public")));

// Database Connection
require("./config/db");

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.use(upload.single("photo"));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.set("view engine", "ejs");

// Session Configuration
app.use(
  session({
    secret: "yourSecretKey",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 600000 },
  })
);

// Routes
const authRoutes = require("./routes/auth");
const catRoutes = require("./routes/cats");
app.use("/", authRoutes);
app.use("/cats", catRoutes);
app.use((req, res, next) => {
  res.setTimeout(120000, () => {
    // 2 minutes
    console.log("Request timed out.");
    res.status(408).send("Request timed out");
  });
  next();
});

// Routes
app.use("/cats-purchased", catsPurchasedRoutes);
app.use("/users", usersRoutes);
app.use("/cat-reviews", catReviewsRoutes);

// Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
