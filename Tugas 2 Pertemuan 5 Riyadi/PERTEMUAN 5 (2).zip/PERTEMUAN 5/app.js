const express = require('express')
const mysql = require('mysql2')
const bodyParser = require('body-parser')
const session = require('express-session');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json());
app.use(session({
    secret: 'abc123',
    resave: false,
    saveUninitialized: true
}));

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'pertemuan5'
});

connection.connect((err) => {
    if (err) {
        console.error("Terjadi esalahan dalam Koneksi ke MySQL: ", err.stack);
        return;
    }
    console.log("Koneksi MySQL berhasil dengan id " + connection.threadId);
})

app.set('view engine', 'ejs');

//routing CRUD

//Read
app.get('/', (req, res) => {
    const flash = req.session.flash || null;
    req.session.flash = null;

    const query = 'SELECT * FROM users';
    connection.query(query, (err, results) => {
        res.render('index', { users: results, flash: flash });
    });
});

//Create
app.post('/add', (req, res) => {
    const { name, email, phone } = req.body;
    const query = 'INSERT INTO users (name, email, phone) VALUES (?,?,?)';
    connection.query(query, [name, email, phone], (err, result) => {
        if (err) {
            req.session.flash = { type: 'error', message: 'Gagal menambahkan users.' };
        } else {
            req.session.flash = { type: 'success', message: 'Berhasil menambahkan users.' };
        }
        res.redirect('/');
    });
});


//Update
app.get('/edit/:id', (req, res) => {
    const query = 'SELECT * FROM users WHERE id = ?';
    connection.query(query, [req.params.id], (err, results) => {
        if (err) throw err;
        res.render('edit', { user: results[0] });
    });
});

app.post('/update/:id', (req, res) => {
    const { name, email, phone } = req.body;
    const query = 'UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?';
    connection.query(query, [name, email, phone, req.params.id], (err, result) => {
        if (err) {
            req.session.flash = { type: 'error', message: 'Gagal mengubah users.' };
        } else {
            req.session.flash = { type: 'success', message: 'Berhasil mengubah users.' };
        }
        res.redirect('/');
    })
});

//Delete
app.get('/delete/:id', (req, res) => {
    const query = 'DELETE FROM users WHERE id = ?';
    connection.query(query, [req.params.id], (err, results) => {
        if (err) {
            req.session.flash = { type: 'error', message: 'Gagal menghapus users.' };
        } else {
            req.session.flash = { type: 'success', message: 'Berhasil menghapus users.' };
        }
        res.redirect('/');
    });
});

app.listen(3000, () => {
    console.log("Server erjalan di port 3000, buka web melalui http://localhost:3000");
})